package com.ericliudeveloper.withmvp;

/**
 * Created by liu on 12/05/15.
 */
public interface ContextFace {

    void startActivity(Class<?> dest);
}
